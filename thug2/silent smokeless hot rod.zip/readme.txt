installation steps:

1. optionally back up your THUG2 installation, or at least the Game/Data directory, as this overwrites files directly
2. extract the zip
3. copy-paste the Game folder in the unzipped folder over your THUG2's Game folder
4. launch the game, enjoy your quiet smokeless hot rod

---

how does this work? ask sam in the Tony Hawk speedrun discord, but here is a short overview:

- decompile manualtricks.qb with a QScript.QDecompile.App executable
- edit the Trick_HotRod struct
    - to remove the smoke, change "InitAnim = Special_Jesse_HotRod_Init" to "InitAnim = Nosemanual" and "FromAirAnim = Special_Jesse_HotRod_Init" to "FromAirAnim = NoseManualFromAir"
    - (hot rod behaves vaguely like a nosemanual so these animations look ok)
    - to remove the sound effect, delete "stream = Spec_JesseJ01" entirely
- recompile manualtricks.qb with a QScript.QCompile.App executable
- to force the game to use the file on disk and skip the precompiled version, save a blank file over Game/Data/pre/qb_scripts.prx